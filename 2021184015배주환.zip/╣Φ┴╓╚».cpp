#include <Windows.h>
#include <tchar.h>
#include <vector>
#include <string>
#include <cmath>
#include <random>
#include <iostream>
#include <ctime>
#include "resource.h"

using namespace std;

HINSTANCE g_hInst;
LPCTSTR lpszClass = L"Inversus";
LPCTSTR lpszWindowName = L"Inversus";

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPSTR lpszCmdParam, int nCmdShow)
{
    HWND hWnd;
    MSG Message;
    WNDCLASSEX WndClass;
    g_hInst = hInstance;

    WndClass.cbSize = sizeof(WndClass);
    WndClass.style = CS_HREDRAW | CS_VREDRAW;
    WndClass.lpfnWndProc = (WNDPROC)WndProc;
    WndClass.cbClsExtra = 0;
    WndClass.cbWndExtra = 0;
    WndClass.hInstance = hInstance;
    WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    WndClass.hCursor = LoadCursor(NULL, IDC_HAND);
    WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    WndClass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
    WndClass.lpszClassName = lpszClass;
    WndClass.hIconSm = LoadIcon(NULL, IDI_QUESTION);
    RegisterClassEx(&WndClass);

    hWnd = CreateWindow(lpszClass, lpszWindowName, WS_OVERLAPPEDWINDOW,
        250, 0, 1000, 800, NULL, (HMENU)NULL, hInstance, NULL);

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    while (GetMessage(&Message, 0, 0, 0)) {
        TranslateMessage(&Message);
        DispatchMessage(&Message);
    }
    return Message.wParam;
}

enum RectangleType {
    BLACK,
    WHITE
};

struct MapRect {
    int size;
    int row;
    int col;
    RectangleType type;
};
MapRect mapRect = { 75, 8, 12, BLACK };
RectangleType rectType[8][12];

struct MainChar {
    int size;
    int bullet;
    int x;
    int y;
};
MainChar mainChar = { 70, 6, 480, 455};
bool hardMode = false;
bool gamePaused = false;

int oldX, oldY;

void DrawMainChar(HDC mDC) {
    int centerX = mainChar.x - mainChar.size / 2 + 50;
    int centerY = mainChar.y - mainChar.size / 2 + 3;

    HBRUSH hBlackBrush = CreateSolidBrush(RGB(0, 0, 0));
    HBRUSH oldBrush = (HBRUSH)SelectObject(mDC, hBlackBrush);

    RoundRect(mDC, centerX, centerY, centerX + mainChar.size, centerY + mainChar.size, 10, 10);

    SelectObject(mDC, oldBrush);
    DeleteObject(hBlackBrush);
}

void crash() {
    int oldX = mainChar.x;
    int oldY = mainChar.y;

    for (int i = 0; i < mapRect.row; ++i) {
        for (int j = 0; j < mapRect.col; ++j) {
            if (rectType[i][j] == BLACK) {
                int rectX = j * mapRect.size;
                int rectY = i * mapRect.size;
                if (mainChar.x + mainChar.size >= rectX && mainChar.x <= rectX + mapRect.size &&
                    mainChar.y + mainChar.size >= rectY && mainChar.y <= rectY + mapRect.size) {
                    mainChar.x = oldX;
                    mainChar.y = oldY;
                    return;
                }
            }
        }
    }
}

void charMove(HWND hWnd) {
    if (gamePaused) {
        return;
    }

    int oldX = mainChar.x;
    int oldY = mainChar.y;
    int dx = 0;
    int dy = 0;
    
    if (GetAsyncKeyState('W') & 0x8000) {
        dy -= 3;
    }
    if (GetAsyncKeyState('A') & 0x8000) {
        dx -= 3;
    }
    if (GetAsyncKeyState('S') & 0x8000) {
        dy += 3;
    }
    if (GetAsyncKeyState('D') & 0x8000) {
        dx += 3;
    }

    mainChar.x += dx;
    mainChar.y += dy;

    crash();
}

void gameStart() {
    mainChar.bullet = 6;
    gamePaused = false;
}

void gamePause() {
    gamePaused = !gamePaused;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM IParam) {
    PAINTSTRUCT ps;
    HDC hDC, mDC;
    HBITMAP hBitmap;
    static RECT rect;
    COLORREF color;
    HBRUSH hBrush, oldBrush;

    switch (iMessage) {
    case WM_CREATE:
        srand((unsigned int)time(NULL));
        SetTimer(hWnd, 1, 10, NULL);
        break;
    case WM_TIMER:
        if (!gamePaused) {
            charMove(hWnd);
            InvalidateRect(hWnd, NULL, false);
        }
        break;
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case ID_GAME_START:
            gameStart();
            break;
        case ID_GAME_PAUSE:
            gamePause();
            break;
        case ID_GAME_END:
            PostQuitMessage(0);
            break;
        case ID_MODE_EASY:
            mapRect.row = 8;
            mapRect.col = 12;
            mapRect.size = 75;
            hardMode = false;
            InvalidateRect(hWnd, NULL, false);
            break;
        case ID_MODE_NORMAL:
            mapRect.row = 14;
            mapRect.col = 20;
            mapRect.size = 45;
            hardMode = false;
            InvalidateRect(hWnd, NULL, false);
            break;
        case ID_MODE_HARD:
            hardMode = true;
            mapRect.row = 14;
            mapRect.col = 20;
            mapRect.size = 45;
            InvalidateRect(hWnd, NULL, false);
            break;
        case ID_MODE_UNBEATABLE:
            break;
        }
        break;
    case WM_PAINT:
    {
        GetClientRect(hWnd, &rect);
        hDC = BeginPaint(hWnd, &ps);
        mDC = CreateCompatibleDC(hDC);
        hBitmap = CreateCompatibleBitmap(hDC, rect.right, rect.bottom);
        SelectObject(mDC, (HBITMAP)hBitmap);

        FillRect(mDC, &rect, (HBRUSH)(COLOR_WINDOW + 1));

        int centerX = (rect.right - rect.left - mapRect.size * mapRect.col) / 2;
        int centerY = (rect.bottom - rect.top - mapRect.size * mapRect.row) / 2 + 50;

        HBRUSH hBrush = CreateSolidBrush(RGB(192, 192, 192));
        RECT fillRect = { 0, 100, rect.right, centerY };
        FillRect(mDC, &fillRect, hBrush);
        fillRect = { 0, centerY + mapRect.size * mapRect.row, rect.right, rect.bottom };
        FillRect(mDC, &fillRect, hBrush);
        fillRect = { 0, centerY, centerX, centerY + mapRect.size * mapRect.row };
        FillRect(mDC, &fillRect, hBrush);
        fillRect = { centerX + mapRect.size * mapRect.col, centerY, rect.right, centerY + mapRect.size * mapRect.row };
        FillRect(mDC, &fillRect, hBrush);
        DeleteObject(hBrush);

        HBRUSH blackBrush = CreateSolidBrush(RGB(0, 0, 0));
        HPEN grayPen = CreatePen(PS_SOLID, 1, RGB(192,192,192));
        HBRUSH whiteBrush = CreateSolidBrush(RGB(255, 255, 255));

        RectangleType rectType[8][12] = {
        {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, BLACK, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, WHITE, WHITE, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, BLACK, WHITE, WHITE, WHITE, BLACK, BLACK, BLACK, BLACK},
        {BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK}
        };

        for (int i = 0; i < mapRect.row; ++i) {
            for (int j = 0; j < mapRect.col; ++j) {
                if (rectType[i][j] == BLACK) {
                    SelectObject(mDC, blackBrush);
                    SelectObject(mDC, grayPen);
                    Rectangle(mDC, centerX + j * mapRect.size, centerY + i * mapRect.size,
                        centerX + (j + 1) * mapRect.size, centerY + (i + 1) * mapRect.size);
                }
                else if (rectType[i][j] == WHITE) {
                    SelectObject(mDC, whiteBrush);
                    SelectObject(mDC, grayPen);
                    Rectangle(mDC, centerX + j * mapRect.size, centerY + i * mapRect.size,
                        centerX + (j + 1) * mapRect.size, centerY + (i + 1) * mapRect.size);
                }
            }
        }

        DeleteObject(whiteBrush);
        DeleteObject(blackBrush);
        DeleteObject(grayPen);
        DeleteObject(grayPen);

        if (hardMode) {
            int redRect = rand() % 2 + 6;
            HBRUSH redBrush = CreateSolidBrush(RGB(255, 0, 0));
            for (int i = 0; i < redRect; ++i) {
                int randomRow = rand() % mapRect.row;
                int randomCol = rand() % mapRect.col;
                fillRect = { centerX + randomCol * mapRect.size, centerY + randomRow * mapRect.size,
                         centerX + (randomCol + 1) * mapRect.size, centerY + (randomRow + 1) * mapRect.size };
                FillRect(mDC, &fillRect, redBrush);
            }
            DeleteObject(redBrush);
        }

        DrawMainChar(mDC);

        BitBlt(hDC, 0, 0, rect.right, rect.bottom, mDC, 0, 0, SRCCOPY);

        DeleteDC(mDC);
        DeleteObject(hBitmap);
        EndPaint(hWnd, &ps);
    }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hWnd, iMessage, wParam, IParam);
}